﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"
//#include <gdiplusheaders.h>
//#include <windows.h>
//#include <Gdiplus.h>

#define CHAR_BIT 8
#define MT4_EXPFUNC __declspec(dllexport)

static unsigned long crc32(int n, unsigned char c[])
{
#define CRC32POLY1 0x04C11DB7UL
#define CRC32POLY2 0xEDB88320UL  /* 左右逆転 */
  int i, j;
  unsigned long r;

  r = 0xFFFFFFFFUL;
  for (i = 0; i < n; i++) {
    r ^= c[i];
    for (j = 0; j < CHAR_BIT; j++)
      if (r & 1) r = (r >> 1) ^ CRC32POLY2;
      else       r >>= 1;
  }
  return r ^ 0xFFFFFFFFUL;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

MT4_EXPFUNC HCURSOR __stdcall GetCursorWithGetCursorInfo(void)
{
  CURSORINFO CursorInfo;
  CursorInfo.cbSize = sizeof(CURSORINFO);
  bool b_GetCursorInfo = GetCursorInfo(&CursorInfo);
  if (!b_GetCursorInfo) {
    CursorInfo.hCursor = 0;
  }
  //FromHICON(CursorInfo.hCursor);
  return CursorInfo.hCursor;
}

MT4_EXPFUNC unsigned long __stdcall GetCursorHashWithGetCursorInfoMask(void)
{
  // www.ne.jp/asahi/krk/kct/programming/saveimagefile.htm
  // www13.plala.or.jp/kymats/study/MULTIMEDIA/load_dib32.html
  LONG imageSize;       // 画像サイズ
  BITMAPFILEHEADER fh;  // ビットマップファイルヘッダ
  CURSORINFO CursorInfo;
  ICONINFO IconInfo;
  BITMAP bmp_mask = { 0 };
  //BITMAP bmp_color = { 0 };
  
  HDC hdc;              // デバイスコンテキスト
  HDC hdc_mem;          // デバイスコンテキスト・メモリ
  LPBYTE bits;          // 画像ビット
  //BITMAP bmp = { 0 };    // ビットマップ構造体
  LONG bpp;             // 画素数
  BITMAPINFO* pbi=NULL;      // ビットマップ情報
  unsigned long ul_crc32 = 0;

  ZeroMemory(&bmp_mask, sizeof(bmp_mask));
  //ZeroMemory(&bmp_color, sizeof(bmp_color));
 
  CursorInfo.cbSize = sizeof(CURSORINFO);
  bool b_GetCursorInfo = GetCursorInfo(&CursorInfo);
  if (!b_GetCursorInfo) {
    CursorInfo.hCursor = 0;
  }
 
  GetIconInfo(CursorInfo.hCursor, &IconInfo);
  if (IconInfo.hbmMask) {
    GetObject(IconInfo.hbmMask, sizeof(bmp_mask), &bmp_mask);
    hdc = GetDC(0);
    hdc_mem = CreateCompatibleDC(hdc);
    ReleaseDC(0, hdc);
    SelectObject(hdc_mem, IconInfo.hbmMask);

    // ファイルサイズ計算
    imageSize = bmp_mask.bmWidthBytes * bmp_mask.bmHeight
      + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    switch (bmp_mask.bmBitsPixel)
    {
    case 2:
      bpp = 2;
      break;
    case 4:
      bpp = 16;
      break;
    case 8:
      bpp = 256;
      break;
    default:
      bpp = 0;
    }
    imageSize += (sizeof(RGBQUAD) * bpp);

    // BITMAPFILEHEADERヘッダー出力
    ZeroMemory(&fh, sizeof(fh));
    memcpy(&fh.bfType, "BM", 2);
    fh.bfSize = imageSize;
    fh.bfReserved1 = 0;
    fh.bfReserved2 = 0;
    fh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER)
      + sizeof(RGBQUAD) * bpp;

    // BITMAPINFOHEADERヘッダー出力
    pbi = new BITMAPINFO[sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * bpp];
    ZeroMemory(pbi, sizeof(BITMAPINFOHEADER));
    pbi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    pbi->bmiHeader.biWidth = bmp_mask.bmWidth;
    pbi->bmiHeader.biHeight = bmp_mask.bmHeight;
    pbi->bmiHeader.biPlanes = 1;
    pbi->bmiHeader.biBitCount = bmp_mask.bmBitsPixel;
    pbi->bmiHeader.biCompression = BI_RGB;
    if (bpp != 0)
    {
      GetDIBColorTable(hdc_mem, 0, bpp, pbi->bmiColors);
    }


    bits = new BYTE[bmp_mask.bmWidthBytes * bmp_mask.bmHeight];
    GetDIBits(hdc_mem, IconInfo.hbmMask, 0, bmp_mask.bmHeight, bits, pbi, DIB_RGB_COLORS);
    ul_crc32 = crc32(bmp_mask.bmWidthBytes * bmp_mask.bmHeight, bits);

    delete[] pbi;
    delete[] bits;
    DeleteDC(hdc_mem);
  }
  
  return ul_crc32;
}


MT4_EXPFUNC unsigned long __stdcall GetCursorHashWithGetCursorInfoColor(void)
{
  // www.ne.jp/asahi/krk/kct/programming/saveimagefile.htm
  // www13.plala.or.jp/kymats/study/MULTIMEDIA/load_dib32.html
  LONG imageSize;       // 画像サイズ
  BITMAPFILEHEADER fh;  // ビットマップファイルヘッダ
  CURSORINFO CursorInfo;
  ICONINFO IconInfo;
  //BITMAP bmp_mask = { 0 };
  BITMAP bmp_color = { 0 };

  HDC hdc;              // デバイスコンテキスト
  HDC hdc_mem;          // デバイスコンテキスト・メモリ
  LPBYTE bits;          // 画像ビット
  //BITMAP bmp = { 0 };    // ビットマップ構造体
  LONG bpp;             // 画素数
  BITMAPINFO* pbi = NULL;      // ビットマップ情報
  unsigned long ul_crc32 = 0;

  //ZeroMemory(&bmp_mask, sizeof(bmp_mask));
  ZeroMemory(&bmp_color, sizeof(bmp_color));

  CursorInfo.cbSize = sizeof(CURSORINFO);
  bool b_GetCursorInfo = GetCursorInfo(&CursorInfo);
  if (!b_GetCursorInfo) {
    CursorInfo.hCursor = 0;
  }

  GetIconInfo(CursorInfo.hCursor, &IconInfo);
  if (IconInfo.hbmColor) {
    GetObject(IconInfo.hbmColor, sizeof(bmp_color), &bmp_color);
    hdc = GetDC(0);
    hdc_mem = CreateCompatibleDC(hdc);
    ReleaseDC(0, hdc);
    SelectObject(hdc_mem, IconInfo.hbmColor);

    // ファイルサイズ計算
    imageSize = bmp_color.bmWidthBytes * bmp_color.bmHeight
      + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    switch (bmp_color.bmBitsPixel)
    {
    case 2:
      bpp = 2;
      break;
    case 4:
      bpp = 16;
      break;
    case 8:
      bpp = 256;
      break;
    default:
      bpp = 0;
    }
    imageSize += (sizeof(RGBQUAD) * bpp);

    // BITMAPFILEHEADERヘッダー出力
    ZeroMemory(&fh, sizeof(fh));
    memcpy(&fh.bfType, "BM", 2);
    fh.bfSize = imageSize;
    fh.bfReserved1 = 0;
    fh.bfReserved2 = 0;
    fh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER)
      + sizeof(RGBQUAD) * bpp;

    // BITMAPINFOHEADERヘッダー出力
    pbi = new BITMAPINFO[sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * bpp];
    ZeroMemory(pbi, sizeof(BITMAPINFOHEADER));
    pbi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    pbi->bmiHeader.biWidth = bmp_color.bmWidth;
    pbi->bmiHeader.biHeight = bmp_color.bmHeight;
    pbi->bmiHeader.biPlanes = 1;
    pbi->bmiHeader.biBitCount = bmp_color.bmBitsPixel;
    pbi->bmiHeader.biCompression = BI_RGB;
    if (bpp != 0)
    {
      GetDIBColorTable(hdc_mem, 0, bpp, pbi->bmiColors);
    }


    bits = new BYTE[bmp_color.bmWidthBytes * bmp_color.bmHeight];
    GetDIBits(hdc_mem, IconInfo.hbmColor, 0, bmp_color.bmHeight, bits, pbi, DIB_RGB_COLORS);
    ul_crc32 = crc32(bmp_color.bmWidthBytes * bmp_color.bmHeight, bits);

    delete[] pbi;
    delete[] bits;
    DeleteDC(hdc_mem);
  }

  return ul_crc32;
}

